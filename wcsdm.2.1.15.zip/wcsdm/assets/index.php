<?php
/**
 * Silence is golden.
 *
 * @package Wcsdm
 */

// phpcs:disable
